import React, { useState, useEffect, useRef } from 'react';
import { Panel } from '../common/Panel';
import { usePolling } from '../../hooks/usePolling';
import { api } from '../../lib/api';
import { Terminal } from 'lucide-react';

interface LogEntry {
  timestamp: string;
  type: 'info' | 'warn' | 'error' | 'success';
  message: string;
}

export const LogFeedPanel: React.FC = () => {
  const { data: status } = usePolling(api.getStatus, 5000);
  const [logs, setLogs] = useState<LogEntry[]>([
     { timestamp: new Date().toISOString(), type: 'info', message: 'SYSTEM INITIALIZATION OK' },
     { timestamp: new Date().toISOString(), type: 'success', message: 'ML-KEM HANDSHAKE ESTABLISHED' }
  ]);
  const endRef = useRef<HTMLDivElement>(null);

  // Generate fake logs over time or listen to state changes
  useEffect(() => {
     if (status?.crypto_state === 'secure') {
       if (Math.random() > 0.8) {
          const newLog: LogEntry = {
            timestamp: new Date().toISOString(),
            type: 'info',
            message: `AES-256 NONCE ROTATED: 0x${Math.floor(Math.random()*1000000).toString(16).toUpperCase()}`
          };
          setLogs(prev => [...prev, newLog].slice(-50));
       }
     }
  }, [status]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getColor = (type: string) => {
    switch(type) {
      case 'info': return 'text-[#a8b0ba]';
      case 'warn': return 'text-alert-amber';
      case 'error': return 'text-alert-red font-bold';
      case 'success': return 'text-signal-green';
      default: return 'text-white';
    }
  };

  return (
    <Panel title="Mission / Security Log" className="h-[200px] lg:h-full flex-1">
       <div className="absolute top-2 right-3">
          <Terminal className="w-3 h-3 text-tactical-text opacity-50" />
       </div>
       <div className="font-mono text-[10px] space-y-1">
          {logs.map((log, i) => (
             <div key={i} className="flex gap-2">
                <span className="text-[#3b4b5e] shrink-0">
                   [{new Date(log.timestamp).toLocaleTimeString([], { hour12: false })}]
                </span>
                <span className={getColor(log.type)}>
                   {log.message}
                </span>
             </div>
          ))}
          <div ref={endRef} />
       </div>
    </Panel>
  );
};
